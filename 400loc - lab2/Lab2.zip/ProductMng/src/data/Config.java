
package data;

public class Config {
    private final String PRODUCT_FILE = "Products.dat";

    public Config() {
    }

    public String getPRODUCT_FILE() {
        return PRODUCT_FILE;
    }
    
}
